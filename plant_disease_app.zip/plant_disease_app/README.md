# 🌿 AI Smart Agriculture System — Plant Disease Detection

> MobileNetV2 · 11 Disease Classes · FastAPI + React + Streamlit

---

## 📁 Folder Structure

```
plant_disease_app/
│
├── model/                          ← PUT YOUR MODEL FILES HERE
│   ├── plant_disease_model.keras   ← trained model (.keras or .h5)
│   └── plant_classes.json          ← class name mapping
│
├── backend/
│   ├── main.py                     ← FastAPI server
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx                 ← Main React component
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
│
└── streamlit_app.py                ← Standalone Streamlit UI
```

---

## 🔧 Step 1 — Place Your Model

Copy your trained model files here:

```
plant_disease_app/model/plant_disease_model.keras
plant_disease_app/model/plant_classes.json       (optional — auto-generated if missing)
```

The `plant_classes.json` from your Colab notebook is at:
`/content/plant_disease/plant_classes.json`

---

## 🚀 Option A — Streamlit App (Easiest)

```bash
cd plant_disease_app

pip install streamlit tensorflow pillow numpy
streamlit run streamlit_app.py
```

Open: http://localhost:8501

The Streamlit app runs **standalone** — no backend needed.  
It loads the model directly and predicts locally.

---

## 🚀 Option B — FastAPI Backend + React Frontend

### Backend

```bash
cd plant_disease_app/backend

pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

API docs: http://localhost:8000/docs

### Frontend

```bash
cd plant_disease_app/frontend

npm install
npm run dev
```

Open: http://localhost:3000

---

## 📡 API Reference

### POST /predict

```bash
curl -X POST http://localhost:8000/predict \
  -F "file=@leaf.jpg"
```

**Response:**
```json
{
  "predicted_class": "tomato late blight",
  "confidence": 91.23,
  "status": "diseased",
  "severity": "High",
  "treatment": "Apply mancozeb + cymoxanil immediately...",
  "fertilizer": "Potassium-rich supplement...",
  "prevention": "Avoid evening irrigation...",
  "inference_ms": 87.4,
  "all_probabilities": {
    "tomato late blight": 0.9123,
    "tomato early blight": 0.0412,
    ...
  }
}
```

### GET /classes

Returns all 11 class names.

### GET /health

Returns model load status.

---

## 🎯 11 Supported Classes

| Class | Status |
|-------|--------|
| pepper bell bacterial spot | Diseased |
| pepper bell healthy | Healthy |
| potato early blight | Diseased |
| potato late blight | Diseased |
| tomato bacterial spot | Diseased |
| tomato early blight | Diseased |
| tomato late blight | Diseased |
| tomato leaf mold | Diseased |
| tomato septoria leaf spot | Diseased |
| tomato target spot | Diseased |
| tomato tomato mosaic virus | Diseased |

---

## 🧠 Model Info

- Architecture: MobileNetV2 (transfer learning)
- Input: 224×224 RGB
- Preprocessing: MobileNetV2 preprocess_input (scale to [-1, 1])
- Training: PlantVillage (21K images) → fine-tuned on PlantDoc (912 images)
- PlantVillage Test Accuracy: **~78%**
- PlantDoc Test Accuracy: **~31%** (domain shift expected)

---

## 💡 Notes

- If model file is missing, FastAPI runs in **mock mode** (random predictions)
- Streamlit app auto-detects if model is available
- React frontend connects to `http://localhost:8000` by default
  - Change via `VITE_API_URL` environment variable
