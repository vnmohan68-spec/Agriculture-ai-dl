import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import {
  Leaf, Upload, AlertTriangle, CheckCircle2, Loader2,
  Droplets, Thermometer, Wind, Activity, ChevronDown,
  Shield, Zap, Sprout
} from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

// ── Helpers ──────────────────────────────────────────────────────────────────
const WEATHER = { temp: "28°C", humidity: "72%", wind: "14 km/h", uv: "High" };

const SOIL_METRICS = [
  { label: "Nitrogen", value: 68, color: "#22c55e" },
  { label: "Phosphorus", value: 45, color: "#3b82f6" },
  { label: "Potassium", value: 81, color: "#a855f7" },
  { label: "pH Level", value: 63, color: "#f59e0b" },
];

const RadialGauge = ({ value, color, label }) => {
  const r = 36, c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <div className="flex flex-col items-center gap-1">
      <svg width="90" height="90" viewBox="0 0 90 90">
        <circle cx="45" cy="45" r={r} fill="none" stroke="#1e293b" strokeWidth="8" />
        <circle
          cx="45" cy="45" r={r} fill="none" stroke={color} strokeWidth="8"
          strokeDasharray={c} strokeDashoffset={offset}
          strokeLinecap="round" transform="rotate(-90 45 45)"
          style={{ transition: "stroke-dashoffset 1.2s ease" }}
        />
        <text x="45" y="50" textAnchor="middle" fill={color} fontSize="15" fontWeight="700">
          {value}%
        </text>
      </svg>
      <span style={{ color: "#94a3b8", fontSize: 11 }}>{label}</span>
    </div>
  );
};

const InsightCard = ({ icon: Icon, title, content, color }) => {
  const [open, setOpen] = useState(false);
  return (
    <motion.div
      whileHover={{ scale: 1.01 }}
      style={{
        background: "rgba(15,23,42,0.7)", border: "1px solid rgba(34,197,94,0.15)",
        borderRadius: 14, overflow: "hidden", cursor: "pointer",
      }}
      onClick={() => setOpen(!open)}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 18px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ background: `${color}22`, borderRadius: 8, padding: 8 }}>
            <Icon size={16} color={color} />
          </div>
          <span style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{title}</span>
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.3 }}>
          <ChevronDown size={16} color="#64748b" />
        </motion.div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }}
            style={{ padding: "0 18px 14px", color: "#94a3b8", fontSize: 13, lineHeight: 1.6 }}
          >
            {content}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// ── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [drag, setDrag] = useState(false);
  const fileRef = useRef();

  const handleFile = useCallback((f) => {
    if (!f || !f.type.startsWith("image/")) return;
    setFile(f);
    setResult(null);
    const reader = new FileReader();
    reader.onload = (e) => setPreview(e.target.result);
    reader.readAsDataURL(f);
  }, []);

  const onDrop = (e) => {
    e.preventDefault(); setDrag(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const predict = async () => {
    if (!file) return;
    setLoading(true); setResult(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const { data } = await axios.post(`${API}/predict`, fd);
      setResult(data);
    } catch (err) {
      setResult({ error: err.response?.data?.detail || "Prediction failed." });
    } finally {
      setLoading(false);
    }
  };

  const isHealthy = result?.status === "healthy";
  const statusColor = result
    ? isHealthy ? "#22c55e"
      : result.severity === "High" ? "#ef4444" : "#f59e0b"
    : "#22c55e";

  return (
    <div style={{ minHeight: "100vh", background: "#020817", fontFamily: "'Inter', sans-serif", color: "#e2e8f0" }}>
      {/* Ambient background blobs */}
      <div style={{
        position: "fixed", inset: 0, overflow: "hidden", pointerEvents: "none", zIndex: 0,
      }}>
        <div style={{
          position: "absolute", width: 600, height: 600, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(34,197,94,0.06) 0%, transparent 70%)",
          top: -200, left: -100,
        }} />
        <div style={{
          position: "absolute", width: 500, height: 500, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(59,130,246,0.05) 0%, transparent 70%)",
          bottom: -100, right: -100,
        }} />
      </div>

      <div style={{ position: "relative", zIndex: 1, maxWidth: 1200, margin: "0 auto", padding: "0 24px 60px" }}>

        {/* ── HERO ── */}
        <motion.div initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }} style={{ textAlign: "center", padding: "60px 0 40px" }}>
          <div style={{
            display: "inline-flex", alignItems: "center", gap: 8,
            background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.3)",
            borderRadius: 999, padding: "6px 16px", marginBottom: 24,
          }}>
            <Leaf size={14} color="#22c55e" />
            <span style={{ color: "#22c55e", fontSize: 12, fontWeight: 600, letterSpacing: 1 }}>
              AI SMART AGRICULTURE SYSTEM
            </span>
          </div>
          <h1 style={{
            fontSize: "clamp(36px, 5vw, 64px)", fontWeight: 800, lineHeight: 1.1, marginBottom: 16,
            background: "linear-gradient(135deg, #ffffff 0%, #22c55e 50%, #3b82f6 100%)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>
            Detect. Diagnose.<br />Protect Your Crops.
          </h1>
          <p style={{ color: "#64748b", fontSize: 18, maxWidth: 540, margin: "0 auto" }}>
            Upload a leaf image — our MobileNetV2 model identifies 11 crop diseases
            in under a second and gives you actionable treatment plans.
          </p>
        </motion.div>

        {/* ── STATS BAR ── */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
          style={{ display: "flex", justifyContent: "center", gap: 40, marginBottom: 48, flexWrap: "wrap" }}>
          {[
            { icon: Zap, label: "< 1s Inference", color: "#f59e0b" },
            { icon: Shield, label: "11 Disease Classes", color: "#22c55e" },
            { icon: Sprout, label: "MobileNetV2 Model", color: "#3b82f6" },
          ].map(({ icon: Icon, label, color }) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Icon size={16} color={color} />
              <span style={{ color: "#64748b", fontSize: 13 }}>{label}</span>
            </div>
          ))}
        </motion.div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>

          {/* ── LEFT COLUMN ── */}
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

            {/* Upload Box */}
            <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
              <div
                onClick={() => fileRef.current.click()}
                onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
                onDragLeave={() => setDrag(false)}
                onDrop={onDrop}
                style={{
                  border: `2px dashed ${drag ? "#22c55e" : "rgba(34,197,94,0.25)"}`,
                  borderRadius: 20, padding: 40, textAlign: "center", cursor: "pointer",
                  background: drag ? "rgba(34,197,94,0.05)" : "rgba(15,23,42,0.6)",
                  backdropFilter: "blur(12px)",
                  transition: "all 0.3s ease",
                  boxShadow: drag ? "0 0 30px rgba(34,197,94,0.15)" : "none",
                }}
              >
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => handleFile(e.target.files[0])} />
                <AnimatePresence mode="wait">
                  {preview ? (
                    <motion.div key="preview" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
                      <img src={preview} alt="preview"
                        style={{ maxHeight: 220, maxWidth: "100%", borderRadius: 12, objectFit: "cover",
                          boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }} />
                      <p style={{ color: "#22c55e", marginTop: 12, fontSize: 13 }}>Click to change image</p>
                    </motion.div>
                  ) : (
                    <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                      <motion.div animate={{ y: [0, -8, 0] }} transition={{ repeat: Infinity, duration: 2 }}>
                        <Upload size={48} color="#22c55e" style={{ margin: "0 auto 16px" }} />
                      </motion.div>
                      <p style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 16, marginBottom: 8 }}>
                        Drop your leaf image here
                      </p>
                      <p style={{ color: "#475569", fontSize: 13 }}>or click to browse • JPG, PNG, WEBP</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>

            {/* Analyze Button */}
            <motion.button
              whileHover={{ scale: 1.02, boxShadow: "0 0 30px rgba(34,197,94,0.4)" }}
              whileTap={{ scale: 0.98 }}
              onClick={predict}
              disabled={!file || loading}
              style={{
                width: "100%", padding: "16px 0", borderRadius: 14, border: "none", cursor: file ? "pointer" : "not-allowed",
                background: file ? "linear-gradient(135deg, #16a34a, #22c55e)" : "rgba(34,197,94,0.15)",
                color: file ? "#ffffff" : "#22c55e", fontSize: 16, fontWeight: 700,
                display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
                transition: "all 0.3s ease",
              }}
            >
              {loading ? <><Loader2 size={20} style={{ animation: "spin 1s linear infinite" }} /> Analyzing...</>
                : <><Leaf size={20} /> Analyze Crop</>}
            </motion.button>

            {/* Weather Widget */}
            <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }}
              style={{
                background: "rgba(15,23,42,0.7)", border: "1px solid rgba(59,130,246,0.15)",
                borderRadius: 16, padding: 20, backdropFilter: "blur(12px)",
              }}>
              <p style={{ color: "#64748b", fontSize: 12, fontWeight: 600, letterSpacing: 1, marginBottom: 16 }}>
                🌤 FIELD CONDITIONS
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {[
                  { icon: Thermometer, label: "Temperature", val: WEATHER.temp, color: "#f59e0b" },
                  { icon: Droplets, label: "Humidity", val: WEATHER.humidity, color: "#3b82f6" },
                  { icon: Wind, label: "Wind Speed", val: WEATHER.wind, color: "#8b5cf6" },
                  { icon: Activity, label: "UV Index", val: WEATHER.uv, color: "#ef4444" },
                ].map(({ icon: Icon, label, val, color }) => (
                  <div key={label} style={{
                    background: "rgba(30,41,59,0.5)", borderRadius: 10, padding: "12px 14px",
                    display: "flex", alignItems: "center", gap: 10,
                  }}>
                    <Icon size={16} color={color} />
                    <div>
                      <p style={{ color: "#e2e8f0", fontWeight: 700, fontSize: 14, lineHeight: 1 }}>{val}</p>
                      <p style={{ color: "#475569", fontSize: 11, marginTop: 2 }}>{label}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* ── RIGHT COLUMN ── */}
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

            {/* Result Card */}
            <AnimatePresence mode="wait">
              {loading && (
                <motion.div key="loading" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }} style={{
                    background: "rgba(15,23,42,0.7)", border: "1px solid rgba(34,197,94,0.2)",
                    borderRadius: 20, padding: 40, textAlign: "center", backdropFilter: "blur(12px)",
                  }}>
                  <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    style={{ display: "inline-block", marginBottom: 16 }}>
                    <Loader2 size={40} color="#22c55e" />
                  </motion.div>
                  <p style={{ color: "#22c55e", fontWeight: 600 }}>Running AI Analysis...</p>
                  <p style={{ color: "#475569", fontSize: 13, marginTop: 8 }}>MobileNetV2 processing your image</p>
                </motion.div>
              )}

              {result && !loading && !result.error && (
                <motion.div key="result" initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ type: "spring", stiffness: 200 }}
                  style={{
                    background: "rgba(15,23,42,0.85)", border: `1px solid ${statusColor}33`,
                    borderRadius: 20, padding: 24, backdropFilter: "blur(12px)",
                    boxShadow: `0 0 40px ${statusColor}15`,
                  }}>
                  {/* Status badge */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
                    <div style={{
                      display: "flex", alignItems: "center", gap: 8,
                      background: `${statusColor}15`, borderRadius: 999, padding: "6px 14px",
                    }}>
                      {isHealthy
                        ? <CheckCircle2 size={14} color={statusColor} />
                        : <AlertTriangle size={14} color={statusColor} />}
                      <span style={{ color: statusColor, fontSize: 12, fontWeight: 700 }}>
                        {isHealthy ? "HEALTHY" : `DISEASED · ${result.severity} RISK`}
                      </span>
                    </div>
                    <span style={{ color: "#475569", fontSize: 12 }}>{result.inference_ms}ms</span>
                  </div>

                  {/* Class name */}
                  <h2 style={{
                    fontSize: 22, fontWeight: 800, textTransform: "capitalize",
                    color: "#f1f5f9", marginBottom: 6,
                  }}>
                    {result.predicted_class.replace(/ /g, "\u00A0")}
                  </h2>

                  {/* Confidence bar */}
                  <div style={{ marginBottom: 20 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                      <span style={{ color: "#64748b", fontSize: 12 }}>Confidence</span>
                      <span style={{ color: statusColor, fontWeight: 700 }}>{result.confidence}%</span>
                    </div>
                    <div style={{ height: 6, background: "#1e293b", borderRadius: 999 }}>
                      <motion.div initial={{ width: 0 }} animate={{ width: `${result.confidence}%` }}
                        transition={{ duration: 1, ease: "easeOut" }}
                        style={{ height: "100%", borderRadius: 999, background: `linear-gradient(90deg, ${statusColor}88, ${statusColor})` }} />
                    </div>
                  </div>

                  {/* Insights */}
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    <InsightCard icon={Zap} title="Treatment" content={result.treatment} color="#ef4444" />
                    <InsightCard icon={Sprout} title="Fertilizer" content={result.fertilizer} color="#22c55e" />
                    <InsightCard icon={Shield} title="Prevention" content={result.prevention} color="#3b82f6" />
                  </div>
                </motion.div>
              )}

              {result?.error && (
                <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  style={{
                    background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)",
                    borderRadius: 20, padding: 30, textAlign: "center",
                  }}>
                  <AlertTriangle size={32} color="#ef4444" style={{ marginBottom: 12 }} />
                  <p style={{ color: "#ef4444", fontWeight: 600 }}>{result.error}</p>
                </motion.div>
              )}

              {!result && !loading && (
                <motion.div key="placeholder" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  style={{
                    background: "rgba(15,23,42,0.5)", border: "1px solid rgba(34,197,94,0.1)",
                    borderRadius: 20, padding: 40, textAlign: "center", backdropFilter: "blur(12px)",
                  }}>
                  <Leaf size={48} color="rgba(34,197,94,0.3)" style={{ margin: "0 auto 16px" }} />
                  <p style={{ color: "#334155" }}>Upload an image and click Analyze</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Soil Health */}
            <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 }}
              style={{
                background: "rgba(15,23,42,0.7)", border: "1px solid rgba(34,197,94,0.12)",
                borderRadius: 16, padding: 20, backdropFilter: "blur(12px)",
              }}>
              <p style={{ color: "#64748b", fontSize: 12, fontWeight: 600, letterSpacing: 1, marginBottom: 20 }}>
                🌱 SOIL HEALTH DASHBOARD
              </p>
              <div style={{ display: "flex", justifyContent: "space-around", flexWrap: "wrap", gap: 12 }}>
                {SOIL_METRICS.map((m) => <RadialGauge key={m.label} {...m} />)}
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #020817; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @media (max-width: 768px) {
          .grid-2col { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
