"""
Plant Disease Detection — FastAPI Backend
Model: MobileNetV2 | Classes: 11 | Input: 224x224
"""

import io, time, json
from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

# ── Config ────────────────────────────────────────────────────────────────────
MODEL_PATH   = Path("model/plant_disease_model.keras")   # or .h5
CLASS_MAP    = Path("model/plant_classes.json")
IMG_SIZE     = (224, 224)

DISEASE_INFO = {
    "pepper bell bacterial spot": {
        "status": "diseased",
        "treatment": "Apply copper-based bactericides. Remove infected leaves immediately.",
        "fertilizer": "Balanced NPK 10-10-10. Avoid excess nitrogen.",
        "prevention": "Use disease-free seeds. Rotate crops every 2 seasons. Maintain proper spacing.",
        "severity": "Moderate",
    },
    "pepper bell healthy": {
        "status": "healthy",
        "treatment": "No treatment needed. Continue regular monitoring.",
        "fertilizer": "Balanced NPK 10-10-10 with micronutrients.",
        "prevention": "Maintain proper irrigation. Monitor for early signs of disease.",
        "severity": "None",
    },
    "potato early blight": {
        "status": "diseased",
        "treatment": "Apply chlorothalonil or mancozeb fungicide. Remove affected foliage.",
        "fertilizer": "Potassium-rich fertilizer (K2O). Avoid excess nitrogen.",
        "prevention": "Plant certified disease-free tubers. Avoid overhead irrigation.",
        "severity": "Moderate",
    },
    "potato late blight": {
        "status": "diseased",
        "treatment": "Apply metalaxyl or cymoxanil fungicide immediately. Destroy infected plants.",
        "fertilizer": "Calcium and potassium supplements to strengthen cell walls.",
        "prevention": "Use resistant varieties. Ensure proper drainage. Monitor humidity.",
        "severity": "High",
    },
    "tomato bacterial spot": {
        "status": "diseased",
        "treatment": "Copper-based bactericides + mancozeb. Prune infected branches.",
        "fertilizer": "Reduce nitrogen. Add calcium nitrate to strengthen tissue.",
        "prevention": "Avoid wet foliage. Use drip irrigation. Crop rotation mandatory.",
        "severity": "Moderate",
    },
    "tomato early blight": {
        "status": "diseased",
        "treatment": "Apply azoxystrobin or chlorothalonil fungicide every 7–10 days.",
        "fertilizer": "Balanced fertilizer. Add magnesium sulfate for leaf strength.",
        "prevention": "Mulch soil. Stake plants for air circulation. Remove lower leaves.",
        "severity": "Moderate",
    },
    "tomato late blight": {
        "status": "diseased",
        "treatment": "Apply mancozeb + cymoxanil immediately. Remove all infected tissue.",
        "fertilizer": "Potassium-rich supplement. Reduce nitrogen input.",
        "prevention": "Avoid evening irrigation. Use resistant varieties. Improve airflow.",
        "severity": "High",
    },
    "tomato leaf mold": {
        "status": "diseased",
        "treatment": "Apply copper oxychloride or chlorothalonil. Increase ventilation.",
        "fertilizer": "Balanced nutrition. Avoid over-fertilizing with nitrogen.",
        "prevention": "Reduce humidity below 85%. Space plants properly. Remove debris.",
        "severity": "Moderate",
    },
    "tomato septoria leaf spot": {
        "status": "diseased",
        "treatment": "Apply chlorothalonil or mancozeb. Remove lower infected leaves.",
        "fertilizer": "Calcium and potassium supplement. Moderate nitrogen.",
        "prevention": "Avoid overhead watering. Rotate crops. Use mulch to prevent splash.",
        "severity": "Moderate",
    },
    "tomato target spot": {
        "status": "diseased",
        "treatment": "Apply azoxystrobin or tebuconazole fungicide. Destroy crop debris.",
        "fertilizer": "Balanced NPK. Add boron micronutrient.",
        "prevention": "Avoid plant stress. Ensure proper drainage. Monitor regularly.",
        "severity": "Moderate",
    },
    "tomato tomato mosaic virus": {
        "status": "diseased",
        "treatment": "No chemical cure. Remove and destroy infected plants immediately.",
        "fertilizer": "Balanced nutrition to support plant immunity.",
        "prevention": "Use virus-free seeds. Control aphid vectors. Disinfect tools.",
        "severity": "High",
    },
}

# ── App Init ──────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Plant Disease Detection API",
    version="1.0.0",
    description="AI-powered crop disease classification using MobileNetV2",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Model Loading (startup event) ─────────────────────────────────────────────
model = None
class_names = []

@app.on_event("startup")
async def load_model():
    global model, class_names
    print("Loading model...")
    t0 = time.time()

    if not MODEL_PATH.exists():
        print(f"WARNING: Model not found at {MODEL_PATH}. Using mock mode.")
        return

    model = tf.keras.models.load_model(str(MODEL_PATH))
    model.predict(np.zeros((1, 224, 224, 3)))  # warm-up pass

    if CLASS_MAP.exists():
        with open(CLASS_MAP) as f:
            data = json.load(f)
        class_names = data["classes"]
    else:
        class_names = sorted(DISEASE_INFO.keys())

    print(f"Model loaded in {time.time()-t0:.2f}s | {len(class_names)} classes")


# ── Preprocessing ─────────────────────────────────────────────────────────────
def preprocess_image(image_bytes: bytes) -> np.ndarray:
    try:
        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        img = img.resize(IMG_SIZE, Image.LANCZOS)
        arr = np.array(img, dtype=np.float32)
        arr = np.expand_dims(arr, axis=0)
        arr = preprocess_input(arr)          # scale to [-1, 1]
        return arr
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Image error: {str(e)}")


# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"status": "online", "model": str(MODEL_PATH), "classes": len(class_names)}


@app.get("/health")
def health():
    return {"status": "healthy", "model_loaded": model is not None}


@app.get("/classes")
def get_classes():
    return {"classes": class_names, "total": len(class_names)}


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image.")

    t0 = time.time()
    image_bytes = await file.read()
    arr = preprocess_image(image_bytes)

    if model is None:
        # Mock response when model not loaded (dev mode)
        import random
        idx = random.randint(0, len(class_names) - 1)
        conf = round(random.uniform(0.75, 0.99), 4)
        predicted_class = class_names[idx]
    else:
        preds = model.predict(arr, verbose=0)[0]
        idx = int(np.argmax(preds))
        conf = float(preds[idx])
        predicted_class = class_names[idx]

    info = DISEASE_INFO.get(predicted_class, {})
    inference_ms = round((time.time() - t0) * 1000, 1)

    all_probs = {}
    if model is not None:
        preds_list = model.predict(arr, verbose=0)[0].tolist()
        all_probs = {class_names[i]: round(preds_list[i], 4) for i in range(len(class_names))}

    return JSONResponse({
        "predicted_class": predicted_class,
        "confidence": round(conf * 100, 2),
        "status": info.get("status", "unknown"),
        "severity": info.get("severity", "Unknown"),
        "treatment": info.get("treatment", "Consult an agronomist."),
        "fertilizer": info.get("fertilizer", "Apply balanced NPK."),
        "prevention": info.get("prevention", "Monitor regularly."),
        "inference_ms": inference_ms,
        "all_probabilities": all_probs,
    })
